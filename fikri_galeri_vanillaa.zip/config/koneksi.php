<?php
$host = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'galeri_foto';

$koneksi = mysqli_connect($host, $userdb, $passdb, $namedb);

// if ($koneksi) {
//     echo "terhubung";
// }
// else{
//     echo "gagal terhubung";
// }
?>